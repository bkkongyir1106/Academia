DIST_CHOICES <- c(
  "exponential", "lognormal", "chi_square", "gamma", "t", "f", "uniform",
  "laplace", "cauchy", "gumbel", "weibull", "beta", "logistic", "pareto",
  "contaminated", "normal"
)

TEST_CODES <- c("SW", "SF", "LF", "KS", "JB", "SKEW", "KURT", "DAP", "AD", "CVM")

FAMILIES <- list(
  one_sample = list(
    label = "One-sample: t-test vs selected alternative",
    test_type = "onesample_ttest",
    functions = c(
      gen_data = "onesample_data",
      get_parameters = "onesample_parameters",
      fn_to_get_norm_obj = "raw_data",
      fn_for_ds_test_1 = "one_sample_t_test"
    ),
    alternatives = list(
      sign = list(label = "Sign test", suffix = "sign", fn_for_ds_test_2 = "sign_test"),
      boxcox = list(label = "Box-Cox t-test", suffix = "boxcox", fn_for_ds_test_2 = "boxcox_t_test"),
      randomized_sign = list(label = "Randomized sign test", suffix = "randomized_sign", fn_for_ds_test_2 = "randomized_sign_pvalue"),
      permutation = list(label = "Sign-flip permutation t-test", suffix = "permutation", fn_for_ds_test_2 = "one_sample_perm_test")
    ),
    effect_size = 0.5,
    center_by = "median",
    distributions = c("exponential", "normal"),
    extra = list()
  ),
  two_sample = list(
    label = "Two-sample: t-test vs selected alternative",
    test_type = "twosample_ttest",
    functions = c(
      gen_data = "two_sample_data",
      get_parameters = "twosample_parameters",
      fn_to_get_norm_obj = "raw_data",
      fn_for_ds_test_1 = "twosample_t_test"
    ),
    alternatives = list(
      mann_whitney = list(label = "Mann-Whitney U", suffix = "mann_whitney", fn_for_ds_test_2 = "Mann_whitney_U_test"),
      permutation = list(label = "Label-permutation Welch test", suffix = "permutation", fn_for_ds_test_2 = "two_sample_perm_test")
    ),
    effect_size = 0.5,
    center_by = "median",
    distributions = c("exponential", "normal"),
    extra = list()
  ),
  anova = list(
    label = "One-way ANOVA: F-test vs selected alternative",
    test_type = "anova",
    functions = c(
      gen_data = "anova_gen_data",
      get_parameters = "anova_parameters",
      fn_to_get_norm_obj = "anova_residuals",
      fn_for_ds_test_1 = "one_way_anova"
    ),
    alternatives = list(
      kruskal_wallis = list(label = "Kruskal-Wallis", suffix = "kruskal_wallis", fn_for_ds_test_2 = "kruskal_wallis_test"),
      permutation = list(label = "Permutation ANOVA", suffix = "permutation", fn_for_ds_test_2 = "permutation_anova")
    ),
    effect_size = "0, 0, 0.5",
    center_by = "median",
    distributions = c("exponential", "normal"),
    extra = list()
  ),
  regression = list(
    label = "Regression: OLS slope test vs selected alternative",
    test_type = "regression_ols",
    functions = c(
      gen_data = "reg_data",
      get_parameters = "reg_parameters",
      fn_to_get_norm_obj = "reg_residuals",
      fn_for_ds_test_1 = "simple_linear_reg"
    ),
    alternatives = list(
      rank = list(label = "Rank-based regression", suffix = "rank", fn_for_ds_test_2 = "rank_regression"),
      permutation = list(label = "Permutation regression", suffix = "permutation", fn_for_ds_test_2 = "perm_regression")
    ),
    effect_size = 0.5,
    center_by = "mean",
    distributions = c("exponential", "normal"),
    extra = list(x_dist = "exponential", x_par = 1, error_par = NULL)
  )
)

# Parse a comma-separated numeric setting, or use its supplied default.
parse_nums <- function(txt, default = numeric(0)) {
  if (is.null(txt) || !nzchar(trimws(txt))) return(default)
  values <- suppressWarnings(as.numeric(strsplit(txt, "[,;[:space:]]+")[[1]]))
  values[is.finite(values)]
}

# Parse a scalar threshold or named sample-size/threshold pairs.
parse_threshold <- function(txt) {
  txt <- trimws(txt %||% "")
  if (!nzchar(txt)) return(NULL)
  if (grepl("=", txt, fixed = TRUE)) {
    parts <- strsplit(txt, ",")[[1]]
    names <- trimws(sub("=.*", "", parts))
    values <- suppressWarnings(as.numeric(sub(".*=", "", parts)))
    return(stats::setNames(values, names))
  }
  suppressWarnings(as.numeric(txt))
}

# Define the dashboard colors, fonts, and layout rules.
build_theme <- function() {
  bslib::bs_add_rules(
    bslib::bs_theme(
      version = 5,
      bg = "#0f1419",
      fg = "#e6edf3",
      primary = "#4c8bf5",
      success = "#3fb950",
      "card-bg" = "#161b22",
      "card-border-color" = "#30363d"
    ),
    "
    .navbar { background-color: #21262d !important; border-bottom: 2px solid #4c8bf5 !important; }
    .navbar .nav-link { color: #fff !important; font-weight: 600; border-radius: 7px; margin: 4px 3px; }
    .navbar .nav-link.active { background-color: #4c8bf5 !important; }
    pre, .shiny-text-output { color: #e6edf3; }
    #pretestsim-busy-bar {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      z-index: 20000;
      background: rgba(76, 139, 245, 0.16);
      opacity: 0;
      transition: opacity 140ms ease-in-out;
      overflow: hidden;
    }
    #pretestsim-busy-bar .bar {
      width: 38%;
      height: 100%;
      background: linear-gradient(90deg, #58a6ff, #3fb950, #58a6ff);
      box-shadow: 0 0 14px rgba(88, 166, 255, 0.55);
      animation: pretestsim-progress-slide 1.15s ease-in-out infinite;
    }
    body.pretestsim-running #pretestsim-busy-bar {
      opacity: 1;
    }
    .run-progress-toast {
      display: none;
      position: fixed;
      top: 1rem;
      right: 1rem;
      z-index: 20001;
      width: 360px;
      max-width: calc(100vw - 2rem);
      border: 1px solid #58a6ff;
      border-radius: 8px;
      background: #161b22;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.38);
      padding: 0.85rem 1rem;
    }
    body.pretestsim-running .run-progress-toast {
      display: block;
    }
    .run-progress-panel {
      display: none;
      margin-top: 0.75rem;
      border: 1px solid #30363d;
      border-radius: 8px;
      background: #161b22;
      padding: 0.75rem 0.85rem;
    }
    body.pretestsim-running .run-progress-panel {
      display: block;
    }
    .run-progress-title {
      color: #e6edf3;
      font-weight: 700;
      font-size: 0.9rem;
      margin-bottom: 0.45rem;
    }
    .run-progress-track {
      height: 8px;
      border-radius: 999px;
      background: #0f1419;
      border: 1px solid #30363d;
      overflow: hidden;
    }
    .run-progress-fill {
      width: 42%;
      height: 100%;
      border-radius: 999px;
      background: linear-gradient(90deg, #4c8bf5, #3fb950);
      animation: pretestsim-progress-slide 1.15s ease-in-out infinite;
    }
    .run-progress-detail {
      color: #8b949e;
      font-size: 0.78rem;
      margin-top: 0.45rem;
      line-height: 1.3;
    }
    @keyframes pretestsim-progress-slide {
      0% { transform: translateX(-110%); }
      50% { transform: translateX(85%); }
      100% { transform: translateX(260%); }
    }
    .phase-grid-wide {
      gap: 1rem;
      align-items: stretch;
    }
    .phase-grid-wide .card {
      min-width: 0;
    }
    .metric-strip {
      margin-bottom: 1rem;
    }
    .metric-tile {
      min-height: 64px;
      border: 1px solid #30363d;
      border-radius: 8px;
      background: #161b22;
      padding: 0.65rem 0.85rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .metric-tile.primary {
      background: #2f6feb;
      border-color: #58a6ff;
    }
    .metric-tile.success {
      background: #2ea043;
      border-color: #56d364;
      color: #06130a;
    }
    .metric-title {
      font-size: 0.78rem;
      font-weight: 700;
      line-height: 1.1;
      margin-bottom: 0.18rem;
    }
    .metric-value,
    .metric-value .shiny-text-output {
      font-size: clamp(1.25rem, 1.75vw, 1.65rem) !important;
      font-weight: 700;
      line-height: 1;
    }
    .metric-strip .card,
    .metric-strip .bslib-value-box,
    .metric-strip .value-box {
      min-height: 96px;
    }
    .metric-strip .card-body,
    .metric-strip .value-box-area {
      padding: 0.85rem 1rem !important;
    }
    .metric-strip .value-box-showcase {
      font-size: 2rem !important;
      width: 3.25rem !important;
    }
    .metric-strip .value-box-title {
      font-size: 0.9rem !important;
      line-height: 1.15;
    }
    .metric-strip .value-box-value,
    .metric-strip .shiny-text-output {
      font-size: 1.65rem !important;
      line-height: 1.05;
    }
    .phase-side-table .card-body,
    .phase-side-table .card-body > div {
      min-width: 0;
    }
    .auc-scroll {
      max-height: 640px;
      overflow: auto;
      padding-right: 0.25rem;
    }
    .auc-scroll table {
      width: 100%;
    }
    .auc-scroll h5 {
      margin-top: 0.35rem;
      color: #e6edf3;
    }
    "
  )
}

# Build the controls and result panels without starting a simulation.
app_ui <- function() {
  bslib::page_navbar(
    title = "Pretest Simulation Studio",
    theme = build_theme(),
    header = tagList(
      tags$div(id = "pretestsim-busy-bar", tags$div(class = "bar")),
      tags$div(
        class = "run-progress-toast",
        div(class = "run-progress-title", "Simulation running"),
        div(class = "run-progress-track", div(class = "run-progress-fill")),
        div(class = "run-progress-detail", "The selected phases are running. This may take a few minutes for larger simulation settings.")
      ),
      tags$script(HTML("
        function pretestsimShowProgress() {
          document.body.classList.add('pretestsim-running');
          var runButton = document.getElementById('run');
          if (runButton) {
            runButton.classList.add('disabled');
            runButton.setAttribute('aria-busy', 'true');
          }
        }
        function pretestsimHideProgress() {
          document.body.classList.remove('pretestsim-running');
          var runButton = document.getElementById('run');
          if (runButton) {
            runButton.classList.remove('disabled');
            runButton.removeAttribute('aria-busy');
          }
        }
        $(document).on('shiny:connected', function() {
          Shiny.addCustomMessageHandler('pretestsim-run-state', function(running) {
            if (running) pretestsimShowProgress(); else pretestsimHideProgress();
          });
          pretestsimHideProgress();
        });
        $(document).on('shiny:disconnected', pretestsimHideProgress);
      "))
    ),
    fillable = TRUE,
    sidebar = bslib::sidebar(
      width = 390,
      title = "Setup & Controls",
      bslib::accordion(
        open = c("assets", "approach", "design", "run"),
        bslib::accordion_panel(
          "Framework",
          value = "assets",
          actionButton("load_fw", "Load framework", class = "btn-secondary w-100"),
          uiOutput("asset_status")
        ),
        bslib::accordion_panel(
          "Normality approach",
          value = "approach",
          radioButtons(
            "approach",
            NULL,
            c("Classical" = "classical", "Custom" = "custom"),
            selected = "classical"
          ),
          conditionalPanel(
            "input.approach == 'classical'",
            selectInput("norm_test", "Adaptive-routing pretest", TEST_CODES, selected = "SW"),
            checkboxGroupInput("battery", "Normality tests for Phase 1 ROC", TEST_CODES,
                               selected = c("SW", "SF", "LF", "JB", "SKEW", "DAP", "AD", "CVM"),
                               inline = TRUE)
          ),
          conditionalPanel(
            "input.approach == 'custom'",
            selectInput(
              "custom_method",
              "Custom normality test",
              c("Fisher SW + AD" = "fisher"),
              selected = "fisher"
            )
          )
        ),
        bslib::accordion_panel(
          "Design & data",
          value = "design",
          selectInput("family", "Downstream comparison",
                      choices = stats::setNames(names(FAMILIES), vapply(FAMILIES, `[[`, character(1), "label"))),
          uiOutput("downstream_alt_ui"),
          selectInput("dist", "Non-normal distribution", setdiff(DIST_CHOICES, "normal"), selected = "exponential"),
          radioButtons("center_by", "Center by", c("median", "mean"), selected = "median", inline = TRUE),
          textInput("effect_size", "Effect size", value = "0.5")
        ),
        bslib::accordion_panel(
          "Simulation parameters",
          value = "params",
          numericInput("Nsim", "Nsim", 200, min = 10, step = 50),
          numericInput("N_tradeoff", "N_tradeoff", 200, min = 10, step = 50),
          numericInput("test_alpha", "test_alpha", 0.05, min = 0.001, max = 0.5, step = 0.01),
          numericInput("single_n", "single_n", 10, min = 3, step = 1),
          textInput("sample_sizes", "sample_sizes", value = "10, 20, 30, 40, 50"),
          textInput("effect_sizes_plot", "effect_sizes_plot", value = "0, 0.1, 0.2, 0.3, 0.5, 0.8, 1.0"),
          numericInput("tol_pos", "Type I inflation tolerance", 0.005, min = 0, step = 0.001),
          numericInput("loss_tol", "Power-loss tolerance", 0.01, min = 0, step = 0.001),
          numericInput("grid_by", "Threshold grid step", 0.025, min = 0.001, max = 0.5, step = 0.005),
          numericInput("sig_by", "Significance-level grid step", 0.005, min = 0.001, max = 0.2, step = 0.001),
          checkboxInput("per_n", "Estimate threshold separately for each sample size", TRUE)
        ),
        bslib::accordion_panel(
          "Phases & run",
          value = "run",
          checkboxGroupInput(
            "phases",
            "Phases",
            c(
              "1 - Normality ROC" = 1,
              "2 - Threshold trade-off" = 2,
              "3 - Power vs Type I ROC" = 3,
              "4 - Power and Type I vs n" = 4,
              "5 - Power vs effect" = 5
            ),
            selected = c(1, 2, 4)
          ),
          uiOutput("threshold_ui"),
          numericInput("seed", "Simulation seed", 12345, min = 1, step = 1),
          checkboxInput("reuse_pvalues", "Reuse the previous run's p-values", FALSE),
          helpText("Reuse requires the same seed, simulation settings, and phase order."),
          actionButton("run", "Run simulation", class = "btn-primary w-100"),
          div(
            class = "run-progress-panel",
            div(class = "run-progress-title", "Simulation running"),
            div(class = "run-progress-track", div(class = "run-progress-fill")),
            div(class = "run-progress-detail", "Please keep this browser tab open. Results will appear when the selected phases finish.")
          )
        )
      )
    ),
    bslib::nav_panel("Run Summary", bslib::layout_columns(
      bslib::card(bslib::card_header("Status"), verbatimTextOutput("run_status")),
      bslib::card(bslib::card_header("Resolved arguments"), verbatimTextOutput("arg_dump"))
    )),
    bslib::nav_panel("Phase 1", bslib::layout_columns(col_widths = c(9, 3), class = "phase-grid-wide",
      bslib::card(bslib::card_header("Normality ROC"), plotOutput("p1_plot", height = 560)),
      bslib::card(class = "phase-side-table",
                  bslib::card_header("AUC table"),
                  div(class = "auc-scroll", DT::DTOutput("p1_auc")))
    )),
    bslib::nav_panel("Phase 2",
      div(class = "metric-strip",
        bslib::layout_columns(col_widths = c(3, 3, 3, 3),
          div(class = "metric-tile primary",
              div(class = "metric-title", "Threshold"),
              div(class = "metric-value", textOutput("p2_star", inline = TRUE))),
          div(class = "metric-tile success",
              div(class = "metric-title", "Power gain"),
              div(class = "metric-value", textOutput("p2_gain", inline = TRUE))),
          div(class = "metric-tile",
              div(class = "metric-title", "Power loss"),
              div(class = "metric-value", textOutput("p2_loss", inline = TRUE))),
          div(class = "metric-tile",
              div(class = "metric-title", "Type I inflation"),
              div(class = "metric-value", textOutput("p2_infl", inline = TRUE)))
        )
      ),
      bslib::card(bslib::card_header("Trade-off"), plotOutput("p2_plot", height = 600))
    ),
    bslib::nav_panel("Phase 3", bslib::card(bslib::card_header("Power vs Type I error"), plotOutput("p3_plot", height = 520))),
    bslib::nav_panel("Phase 4", bslib::layout_columns(col_widths = c(8, 4), class = "phase-grid-wide",
      bslib::card(bslib::card_header("Power and Type I vs n"), plotOutput("p4_plot", height = 560)),
      bslib::card(class = "phase-side-table",
                  bslib::card_header("AUC tables"),
                  div(class = "auc-scroll", uiOutput("p4_tables")))
    )),
    bslib::nav_panel("Phase 5", bslib::card(bslib::card_header("Power vs effect size"), plotOutput("p5_plot", height = 480))),
    bslib::nav_panel("Log & Downloads",
                     bslib::card(bslib::card_header("Console output"), verbatimTextOutput("console_log")),
                     bslib::card(bslib::card_header("Generated files"), uiOutput("downloads")))
  )
}

# Load the framework and run analyses only in response to the Run button.
app_server <- function(input, output, session) {
  fw_rv <- reactiveVal(NULL)
  status <- reactiveVal("Framework not loaded yet.")
  run_state <- reactiveValues(results = NULL, log = "", args = NULL, wd = NULL)

  # Load the bundled framework into this session.
  load_fw <- function() {
    status("Loading bundled framework...")
    fw <- tryCatch(
      load_framework(),
      error = function(e) {
        status(paste("Framework load failed:", conditionMessage(e)))
        NULL
      }
    )
    if (!is.null(fw)) {
      fw_rv(fw)
      status("Loaded bundled framework. Ready to run.")
    }
  }

  observeEvent(TRUE, load_fw(), once = TRUE)
  observeEvent(input$load_fw, load_fw())

  output$asset_status <- renderUI({
    cls <- if (grepl("^Loaded", status())) "text-success" else "text-warning"
    tags$div(class = paste("small", cls), status())
  })

  output$downstream_alt_ui <- renderUI({
    spec <- FAMILIES[[input$family]]
    choices <- stats::setNames(
      names(spec$alternatives),
      vapply(spec$alternatives, `[[`, character(1), "label")
    )
    selectInput("downstream_alt", "Alternative downstream test", choices = choices)
  })

  needs_threshold <- reactive(any(c("3", "4", "5") %in% input$phases) && !("2" %in% input$phases))
  output$threshold_ui <- renderUI({
    if (!needs_threshold()) return(NULL)
    tagList(
      textInput("pretest_threshold", "pretest_threshold", value = "0.05"),
      helpText("Use a scalar, or per-n pairs like 10=0.05, 20=0.04.")
    )
  })

  # Resolve the selected generator and downstream test functions.
  family_functions <- function(fw, family_id) {
    spec <- FAMILIES[[family_id]]
    alt_id <- input$downstream_alt %||% names(spec$alternatives)[1]
    alt <- spec$alternatives[[alt_id]] %||% spec$alternatives[[1]]
    functions <- c(spec$functions, fn_for_ds_test_2 = alt$fn_for_ds_test_2)
    out <- lapply(functions, function(name) {
      if (!exists(name, envir = fw, mode = "function", inherits = FALSE)) {
        stop("Framework function not found: ", name, call. = FALSE)
      }
      get(name, envir = fw, mode = "function", inherits = FALSE)
    })
    c(out, spec$extra)
  }

  # Construct the selected classical or Fisher normality configuration.
  norm_config <- function(fw) {
    if (identical(input$approach, "classical")) {
      return(list(method = "classical", config = list(norm_test = input$norm_test)))
    }
    if (!identical(input$custom_method, "fisher")) {
      stop("Select Fisher SW + AD for the custom normality test.")
    }
    list(method = "custom", config = list(fn = fw$fisher_combined, label = "Fisher SW + AD"))
  }

  # Translate the selected controls into framework arguments.
  build_args <- function(fw) {
    spec <- FAMILIES[[input$family]]
    alt_id <- input$downstream_alt %||% names(spec$alternatives)[1]
    alt <- spec$alternatives[[alt_id]] %||% spec$alternatives[[1]]
    phases <- as.integer(input$phases)
    custom_label <- if (identical(input$approach, "classical")) input$norm_test else input$custom_method
    selected_norm_config <- norm_config(fw)
    args <- c(
      family_functions(fw, input$family),
      list(
        Nsim               = input$Nsim,
        N_tradeoff         = input$N_tradeoff,
        test_type          = paste(spec$test_type, "vs", alt$suffix, custom_label, sep = "_"),
        distributions      = c(input$dist, "normal"),
        norm_config        = selected_norm_config,
        threshold_grid     = seq(0, 1, by = input$grid_by),
        normality_roc_grid = seq(0, 1, by = max(input$grid_by, 0.025)),
        tol_pos            = input$tol_pos,
        loss_tol           = input$loss_tol,
        test_alpha         = input$test_alpha,
        center_by          = input$center_by,
        effect_size        = parse_nums(input$effect_size, spec$effect_size),
        sample_sizes       = parse_nums(input$sample_sizes, c(10, 20, 30, 40, 50)),
        single_n           = input$single_n,
        effect_sizes_plot  = parse_nums(input$effect_sizes_plot, c(0, 0.2, 0.5, 0.8)),
        sig_levels         = seq(0, 1, by = input$sig_by),
        norm_test          = TEST_CODES,
        selected_tests     = if (identical(input$approach, "classical")) input$battery else input$custom_method,
        phases             = phases,
        pretest_threshold  = if (needs_threshold()) parse_threshold(input$pretest_threshold) else NULL,
        per_n_thresholds   = isTRUE(input$per_n),
        save_results       = FALSE,
        save_compression   = "gzip"
      )
    )
    args
  }

  observeEvent(input$run, {
    session$sendCustomMessage("pretestsim-run-state", TRUE)
    on.exit(session$sendCustomMessage("pretestsim-run-state", FALSE), add = TRUE)
    fw <- fw_rv()
    if (is.null(fw)) {
      showNotification("Load the framework first.", type = "error")
      return()
    }
    if (length(input$phases) == 0L) {
      showNotification("Select at least one phase.", type = "warning")
      return()
    }

    args <- tryCatch(build_args(fw), error = function(e) {
      showNotification(conditionMessage(e), type = "error", duration = NULL)
      NULL
    })
    if (is.null(args)) return()
    run_state$args <- args

    # Validate reproducibility controls before creating output files.
    seed <- input$seed %||% 12345
    if (length(seed) != 1L || !is.finite(seed) || seed < 1 ||
        seed > .Machine$integer.max || seed != floor(seed)) {
      showNotification("The simulation seed must be a positive integer.", type = "error")
      return()
    }
    reuse <- isTRUE(input$reuse_pvalues)
    if (reuse && is.null(run_state$wd)) {
      showNotification("Run a simulation before requesting reuse.", type = "error")
      return()
    }

    # A new run receives its own directory; reuse reads the previous run's tables.
    wd <- if (reuse) run_state$wd else tempfile("pretestsim_")
    dir.create(wd, recursive = TRUE, showWarnings = FALSE)
    args$output_dir <- file.path(wd, "results")
    args$pvalue_directory <- file.path(args$output_dir, args$test_type, "pvalue_tables")
    args$reuse_pvalues <- reuse
    run_state$args <- args

    RNGversion("4.2.0")
    set.seed(as.integer(seed), kind = "Mersenne-Twister",
      normal.kind = "Inversion", sample.kind = "Rejection")

    log <- shiny::withProgress(
      message = "Running pretest simulation",
      detail = "Preparing selected phases...",
      value = 0.1,
      {
        capture.output({
          res <- tryCatch(
            {
              shiny::incProgress(0.25, detail = "Running simulation framework...")
              do.call(fw$run_simulation, args)
            },
            error = function(e) {
              cat("ERROR:", conditionMessage(e), "\n")
              NULL
            }
          )
          shiny::incProgress(0.65, detail = "Collecting results...")
        }, type = "output")
      }
    )

    run_state$results <- res
    run_state$log <- paste(log, collapse = "\n")
    run_state$wd <- wd

    if (is.null(run_state$results)) {
      showNotification("Run failed. Check the log.", type = "error", duration = NULL)
    } else {
      showNotification("Run complete.", type = "message")
    }
  }, ignoreInit = TRUE)

  # Check whether the completed analysis includes a requested phase.
  ran <- function(phase) {
    res <- run_state$results
    !is.null(res) && phase %in% res$params$phases_run
  }
  # Access the completed analysis objects.
  obj <- function() run_state$results$objects
  # Access the completed analysis settings.
  par <- function() run_state$results$params
  # Apply plot colors temporarily, then restore the graphics settings.
  dark <- function(expr) {
    op <- graphics::par(
      bg = "#0f1419",
      fg = "#e6edf3",
      col.axis = "#c9d1d9",
      col.lab = "#e6edf3",
      col.main = "#f0f6fc",
      col.sub = "#c9d1d9"
    )
    on.exit(graphics::par(op), add = TRUE)
    expr
  }

  output$run_status <- renderText({
    paste(status(), if (!is.null(run_state$results)) "\nLast run complete." else "\nNo completed run yet.")
  })
  output$arg_dump <- renderText({
    args <- run_state$args
    if (is.null(args)) return("Run a simulation to see resolved arguments.")
    keep <- setdiff(names(args), c("gen_data", "get_parameters", "fn_to_get_norm_obj", "fn_for_ds_test_1", "fn_for_ds_test_2", "norm_config"))
    paste(vapply(keep, function(name) {
      value <- args[[name]]
      paste0(name, " = ", paste(value, collapse = ", "))
    }, character(1)), collapse = "\n")
  })
  output$console_log <- renderText(run_state$log %||% "Run a simulation to see console output.")

  output$p1_plot <- renderPlot({
    validate(need(ran(1), "Run Phase 1 to see ROC curves."))
    roc <- obj()$roc_pval_ds_test
    validate(need(!is.null(roc), "Phase 1 did not return ROC data."))
    tests <- rownames(roc$FPR)
    curves <- lapply(tests, function(test) list(fpr = as.numeric(roc$FPR[test, ]), tpr = as.numeric(roc$TPR[test, ]), label = test, lty = 1))
    dark(fw_rv()$plot_norm_roc_curve(curves = curves, dist_name = par()$distributions[1]))
  })
  output$p1_auc <- DT::renderDT({
    validate(need(ran(1), ""))
    roc <- obj()$roc_pval_ds_test
    validate(need(!is.null(roc), ""))
    tests <- rownames(roc$FPR)
    auc <- vapply(tests, function(test) fw_rv()$compute_auc(as.numeric(roc$FPR[test, ]), as.numeric(roc$TPR[test, ])), numeric(1))
    DT::datatable(data.frame(Test = tests, AUC = round(auc, 4)), rownames = FALSE, options = list(dom = "t"))
  })

  output$p2_star <- renderText({ validate(need(ran(2), "-")); sprintf("%.4f", obj()$param_star) })
  output$p2_gain <- renderText({ validate(need(ran(2), "-")); sprintf("%.4f", obj()$optimal_result$power_gain %||% NA_real_) })
  output$p2_loss <- renderText({ validate(need(ran(2), "-")); sprintf("%.4f", obj()$optimal_result$power_loss %||% NA_real_) })
  output$p2_infl <- renderText({
    validate(need(ran(2), "-"))
    v <- obj()$optimal_result$inflation_non_normal %||% obj()$optimal_result$inflation_normal
    if (is.null(v) || is.na(v)) "n/a" else sprintf("%.4f", v)
  })
  output$p2_plot <- renderPlot({
    validate(need(ran(2), "Run Phase 2 to see trade-off results."))
    dark(fw_rv()$plot_tradeoff_results_generic(obj()$optimal_result))
  })

  output$p3_plot <- renderPlot({
    validate(need(ran(3), "Run Phase 3 to see power vs Type I error."))
    dark(fw_rv()$power_vs_error_roc_plot(obj()$roc_data, nominal_alpha = par()$test_alpha, optimal_result = obj()$optimal_result))
  })

  output$p4_plot <- renderPlot({
    validate(need(ran(4), "Run Phase 4 to see power and Type I error by sample size."))
    dark(fw_rv()$plot_power_type1_results(
      combined_power = obj()$combined_power_n,
      combined_type1 = obj()$combined_type1_n,
      ds_test_methods = par()$ds_test_methods,
      distributions = par()$distributions,
      sample_sizes = par()$sample_sizes,
      test_alpha = par()$test_alpha,
      optimal_result = obj()$optimal_result,
      norm_config = par()$norm_config
    ))
  })
  output$p4_tables <- renderUI({
    validate(need(ran(4), ""))
    tables <- obj()$auc_tables
    do.call(tagList, lapply(names(tables), function(name) {
      tagList(h5(name), tableOutput(paste0("auc_", name)))
    }))
  })
  observe({
    tables <- if (!is.null(run_state$results)) obj()$auc_tables else NULL
    if (is.null(tables)) return()
    for (name in names(tables)) {
      local({
        id <- paste0("auc_", name)
        table <- tables[[name]]
        output[[id]] <- renderTable(table, striped = TRUE, bordered = TRUE)
      })
    }
  })

  output$p5_plot <- renderPlot({
    validate(need(ran(5), "Run Phase 5 to see power by effect size."))
    eff_len <- length(par()$effect_size_input)
    dark(fw_rv()$plot_power_by_effect_size(
      combined_power = obj()$combined_power_effect,
      fixed_n = par()$single_n,
      optimal_result = obj()$optimal_result,
      norm_config = par()$norm_config,
      eff_len = eff_len
    ))
  })

  output$downloads <- renderUI({
    if (is.null(run_state$results) || is.null(run_state$wd)) return(helpText("Run a simulation first."))
    files <- list.files(file.path(run_state$wd, "results"), recursive = TRUE, full.names = TRUE)
    if (!length(files)) return(helpText("No output files found."))
    do.call(tagList, lapply(seq_along(files), function(i) {
      id <- paste0("dl_", i)
      output[[id]] <- downloadHandler(
        filename = function() basename(files[i]),
        content = function(file) file.copy(files[i], file, overwrite = TRUE)
      )
      tags$div(downloadButton(id, basename(files[i]), class = "btn-sm mb-1"))
    }))
  })
}
